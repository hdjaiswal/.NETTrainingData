﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AttributeTypeDemo
{
   public  class Program
    {
        static void Main(string[] args)
        {
            AuthorAttribute atr = (AuthorAttribute)Attribute.GetCustomAttribute(typeof(Employee), typeof(AttributeDemo));

                if(atr==null)
                {
                    Console.WriteLine("Author Attribute is not applied on employee");
                }
                else
                {
                    Console.WriteLine(atr.Name);
            
                }
        }
    }
}
