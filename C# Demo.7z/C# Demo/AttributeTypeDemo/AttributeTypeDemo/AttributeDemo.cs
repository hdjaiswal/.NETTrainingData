﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeTypeDemo
{
    [AttributeUsage(AttributeTargets.Class)]
    public class AttributeDemo:Attribute
    {
        string name;
       
        public void AuthorAttribute(string name)
        {
            this.name=name;
       
        }

        public String Name{get{return name;}}
      

    }
}
