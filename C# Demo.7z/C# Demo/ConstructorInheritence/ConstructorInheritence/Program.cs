﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritence
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee obj1 = new Manager();
            //Manager obj2 = new Employee();
           //Manager obj3 = new Manager();
           // Manager obj4 = new Manager(1);
        }
    }
}
