﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritence
{
   public class Employee
    {

        
        public Employee()
        {
            Console.WriteLine("Employee Default");
        }

        public Employee(int ids)
        {
            Console.WriteLine("Employee parametrized");
        }
    }
}
