﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInheritence
{
   public class Manager:Employee
    {
        public Manager() 
        {
            Console.WriteLine("manager Default");
        }

        public Manager(int id) 
        {
            Console.WriteLine("manager parametrized");
        }
    }
}
