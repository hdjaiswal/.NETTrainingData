﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;


namespace SoapFormatterSerializationDemo
{
   public class Program
    {
        static void Main(string[] args)
        {
            SoapFormat emp = new SoapFormat() { EmployeeID = 101, EmployeeName = "Mukesh", Salary = 1200 };
            FileStream fs = new FileStream("Binary.txt", FileMode.Append, FileAccess.Write);
            SoapFormatter bin = new SoapFormatter();
            bin.Serialize(fs, emp);
            fs.Close();
            fs = new FileStream("Binary.txt", FileMode.Open, FileAccess.Read);
            SoapFormat anotheremp = (SoapFormat)bin.Deserialize(fs);

            Console.WriteLine("EmployeeID:" + anotheremp.EmployeeID);
            Console.WriteLine("Employee Name:" + anotheremp.EmployeeName);

            Console.WriteLine("Employee Salary" + anotheremp.Salary);
            Console.ReadKey();
        }
    }
}
