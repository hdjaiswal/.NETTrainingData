namespace UtilityMethods
{
	public class MultClass
	{
		public static int Mult(int num1, int num2)
		{
			return num1 * num2;
		}
	}
}