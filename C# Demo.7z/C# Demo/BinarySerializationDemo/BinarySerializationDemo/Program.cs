﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BinarySerializationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee() { EmployeeID = 101, EmployeeName = "Mukesh", Salary = 1200 };
            FileStream fs = new FileStream("Binary.txt", FileMode.Append, FileAccess.Write);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(fs, emp);
            fs.Close();
            fs = new FileStream("Binary.txt", FileMode.Open, FileAccess.Read);
            Employee anotheremp = (Employee)bin.Deserialize(fs);

            Console.WriteLine("EmployeeID:" + anotheremp.EmployeeID);
            Console.WriteLine("Employee Name:" + anotheremp.EmployeeName);
           
            Console.WriteLine("Employee Salary" + anotheremp.Salary);
            Console.ReadKey();

        }
    }
}
