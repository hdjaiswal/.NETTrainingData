﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstraintDemo
{

    public class MyClass<T> where T:struct
    {
    }
    public class Customer()
    {
        }

        struct DOB
        {
        }
        struct Customer
        {
        }

        struct string
        {
    }
   public class Program
    {
        static void Main(string[] args)
        {
            MyClass<int> intObj = new MyClass<int>();
            MyClass<string> strObj = new MyClass<string>();
            MyClass<Customer> custObj = new MyClass<Customer>();

        }
    }
}
