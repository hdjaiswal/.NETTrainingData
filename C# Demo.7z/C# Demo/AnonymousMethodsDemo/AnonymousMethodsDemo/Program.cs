﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodsDemo
{
    public delegate void AnonymousDelegate();
    class Program
    {
        public static void Display()
        {
            Console.WriteLine("Display Method is call");
        }
        static void Main(string[] args)
        {
            AnonymousDelegate del = new AnonymousDelegate(Display);
            AnonymousDelegate del1 = delegate
            {
                Console.WriteLine("Anonymous Method is called");
            };
            del1();
            
        }
    }
}
