﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DirectoryDemo2
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the path Name to create directory");
            string dirpath = Console.ReadLine();
            Console.WriteLine("Enter the path Name to create files");
            string filepath = Console.ReadLine();
            DirectoryInfo dir = new DirectoryInfo(dirpath);
            FileInfo file = new FileInfo(filepath);
            if (dir.Exists)
            {

                Console.WriteLine("Directory Name is:" + dir.Name);
                Console.WriteLine("Directory File is:" + dir.Extension);
                FileInfo[] files = dir.GetFiles();
                foreach (FileInfo f in files)
                {
                    Console.WriteLine(f.Name);
                }
            }
            else
            {
                Directory.CreateDirectory(dirpath);

                File.CreateText(filepath);
            }
        }
    }
}
