﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressionDemo
{
    class Program
    {
        public delegate void LamndaDelegate();

        static void Main(string[] args)
        {
            LamndaDelegate anonymous = delegate
            {
                Console.WriteLine("Anonymous Method Called");
            };

            anonymous();
            LamndaDelegate lambda = () => Console.WriteLine("Lambda Expression is Called");
            lambda();
        }
    }
}
