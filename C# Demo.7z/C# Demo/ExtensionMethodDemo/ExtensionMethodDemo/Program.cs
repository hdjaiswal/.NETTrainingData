﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string phone = "123-123-1214";

           string newphone = phone.RemoveNoNumeric();
           Console.WriteLine(newphone);

        }
    }
}
