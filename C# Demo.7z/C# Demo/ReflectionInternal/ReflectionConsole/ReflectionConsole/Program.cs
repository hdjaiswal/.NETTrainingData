﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibraryDemo.dll");
            Type calc = refAssembly.GetType("ReflectionLibraryDemo.Square");

            MemberInfo[] calcMethods = calc.GetMethods();
           

            Console.WriteLine("No of Methods in Calculate Class:" + calcMethods.Length);
            
            foreach(MethodInfo m in calcMethods)
            {
                Console.WriteLine("Method Name:" + m.Name);
                Console.WriteLine("Is Virtual:" + m.IsVirtual);
                //Console.WriteLine("Base Type Name:" + refTypes[i].BaseType);
                //Console.WriteLine("Contains Generic Parameter:" + refTypes[i].ContainsGenericParameters);
                //Console.WriteLine("Full Name:" + refTypes[i].FullName);
                //Console.WriteLine("Guid:" + refTypes[i].GUID);
                //Console.WriteLine("Has Element Type:" + refTypes[i].HasElementType);
                //Console.WriteLine("Is Abstract:" + refTypes[i].IsAbstract);
                //Console.WriteLine("Is Ansi Class:" + refTypes[i].IsAnsiClass);
                //Console.WriteLine("Class Name:" + refTypes[i].IsClass);
                //Console.WriteLine("Is Nested:" + refTypes[i].IsNested);
                //Console.WriteLine("Is Enum:" + refTypes[i].IsEnum);
                //Console.WriteLine("Interface is:" + refTypes[i].IsInterface);
                //ParameterInfo param = m.GetParameters();

                MethodInfo add = calc.GetMethod("drawSquare");
                if(add!=null)
                {
                    object obj=refAssembly,CreateInstance("ReflectionLibraryDemo.Square");
                    string result=(string)add.Invoke(obj,new

            }
           

        }
    }
}
