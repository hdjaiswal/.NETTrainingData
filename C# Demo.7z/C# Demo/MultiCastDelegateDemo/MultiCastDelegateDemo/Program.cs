﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiCastDelegateDemo
{
    delegate void CalcDelegate(int num1,int num2);
    class Program
    {
        static void Main(string[] args)
        {
            Calculate obj = new Calculate();
            CalcDelegate del = new CalcDelegate(obj.Subtract);
            del += new CalcDelegate(obj.Add);
            del += new CalcDelegate(obj.Subtract);
            del += new CalcDelegate(obj.Multiply);
            del -= new CalcDelegate(obj.Division);

            del(20, 5);

            Delegate[] methodList = del.GetInvocationList();
            foreach (Delegate m in methodList)
            {
                Console.WriteLine(m.Method);
            }


       
        }
    }
}
