﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Areaofcircle
{
    class Program
    {


        public void CircleDe(double radius, out double area, out double circumference)
        {
            double pi = 3.14;
            area = pi * radius * radius;
            circumference = 2 * pi * radius;
        }

        static void Main(string[] args)
        {
            Program obj = new Program();
            Console.WriteLine("Enter Radius of Circle:");
            double r = Convert.ToDouble(Console.ReadLine());
            double area, circumference;
            obj.CircleDe(r, out area, out circumference);
            Console.WriteLine("----------------------------Area of the Circle-------------------------------");
            Console.WriteLine("Area:" + area);
            Console.WriteLine("\n");

            Console.WriteLine("----------------------------Circumference of the circle-----------------------");
            Console.WriteLine("Circumference:" + circumference);

            Console.ReadKey();
        }
    }
}
