﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
    public delegate void EventHandlerDelegate(string msg);
    public class EventPublisher
    {
        public event EventHandlerDelegate MyClickEvent;
        public void InvokeClickEvent(string msg)
        {
            if (MyClickEvent != null)
            {
                MyClickEvent(msg);
            }
            else
            {
                Console.WriteLine("There is no event handler available");
            }
        }
    }

    public class Subscriber
    {
        public void HandlerMethod(string msg)
        {
            Console.WriteLine(msg);
            Console.WriteLine("Event Occured");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            EventPublisher obj1 = new EventPublisher();
            Subscriber obj2 = new Subscriber();

            obj1.MyClickEvent += obj2.HandlerMethod;
            obj1.InvokeClickEvent("Hi this is click event");
            Console.ReadKey(); 
        }
    }
}
