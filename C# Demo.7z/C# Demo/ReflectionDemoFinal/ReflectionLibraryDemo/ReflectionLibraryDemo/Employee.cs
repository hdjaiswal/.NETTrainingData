﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibraryDemo
{
    public class Employee
    {
        int id;
        string name;
        string address;
        double salary;

        public int EmpID
        {
            get { return id; }
            set { id = value; }
        }

        public string Empname
        {
            get { return name; }
            set { name = value; }
        }

        public string Empaddress
        {
            get { return address; }
            set { address = value; }
        }

        public double EmpSalary
        {
            get { return salary; }
            set { salary = value; }
        }
    }

    public abstract class Shape:Idrawshape
    {
       public void drawCircle()
        {
            Console.WriteLine("Inside Shape Circle");
        }

        public void drawSquare()
        {
            Console.WriteLine("Inside Shape Square");
        }
    }

    public sealed class Circle : Shape
    {
        public void drawCircle()
        {
            Console.WriteLine("Inside Circle");
        }
    }

    public class Square : Shape
    {
        public void drawSquare()
        {
            Console.WriteLine("Inside Square");
        }
    }

    public interface Idrawshape
    {
         void drawCircle();
         void drawSquare();
    }
}
