﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexersDemo
{
    class Program
    {
        static void Main(string[] args)
        {


            Indexers cal = new Indexers(10);

            cal[0] = 752;
            cal[4] = 753;

            cal[5] = 754;

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine(cal[i]);

            }

        }
    }
}
