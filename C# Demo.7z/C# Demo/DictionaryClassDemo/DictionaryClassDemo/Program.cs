﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryClassDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<string,Employee> objDic = new Dictionary<string,Employee>();
            IDictionary<int, string> dict = new Dictionary<int, string>();
            dict.Add(1, "One");
            dict.Add(2, "Two");
            dict.Add(3, "Three");

            Console.WriteLine(dict.Values);
            

        }
    }
}
