﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceDemo
{
    public class Employee:Interface2,Interface3
    {



        void Interface2.show()
        {
            Console.WriteLine("Show the details");
        }

        void Interface2.Display()
        {
            Console.WriteLine("Display the details");
        }

        void Interface3.show()
        {
            Console.WriteLine("Show the details1");
        }

        void Interface3.Print()
        {
            Console.WriteLine("Print the details");
        }
    }
}
