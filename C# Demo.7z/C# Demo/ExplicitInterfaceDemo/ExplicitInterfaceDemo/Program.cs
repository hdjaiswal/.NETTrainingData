﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Interface2 obj = new Employee();
            Interface3 obj1 = new Employee();

            obj.show();
            obj.Display();

            obj1.show();
            obj1.Print();
           
            

        }
    }
}
