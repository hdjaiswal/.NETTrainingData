﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaWithParameters
{
    class Program
    {
        public delegate double LamndaDelegate(int num,int pow);

        static void Main(string[] args)
        {
            LamndaDelegate anonymous = delegate(int num,int pow)
            {
                return Math.Pow(num, pow);
            };

            anonymous(2,3);
            LamndaDelegate lambda = (num, pow) => { return Math.Pow(num, pow); };
            Console.WriteLine(lambda(2,4));
            Console.ReadKey();
        }
    }
}
