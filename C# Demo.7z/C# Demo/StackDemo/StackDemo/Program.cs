﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace StackDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Stack stackObject = new Stack();
            stackObject.Push("Hi");
            stackObject.Push("My");
            stackObject.Push("Name");
            while (stackObject.Count > 0)
                Console.WriteLine(stackObject.Pop());
            Console.ReadLine();
        }
    }
}
