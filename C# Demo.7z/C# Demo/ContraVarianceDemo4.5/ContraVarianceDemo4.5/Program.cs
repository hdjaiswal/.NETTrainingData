﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContraVarianceDemo4._5
{
    public class Employee
    {

        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public double Salary { get; set; }
        public Employee(int empID, string name, double Sal)
        {
            EmpID = empID;
            EmpName = name;
            Salary = Sal;

        }

    }

    public class EmployeeCamparer : IComparer<Employee>
    {
        int IComparer<Employee>.Compare(Employee x, Employee y)
        {
            if (x.Salary > y.Salary)
                return 1;
            else if (x.Salary == y.Salary)
                return 0;

            return -1;

        }

        public class Manager : Employee
        {
            public int Allowance { get; set; }
            public Manager(int empID, string name, double Sal, int all)
                : base(empID, name, Sal)
            {
                Allowance = all;
            }

        }
        class Program
        {
            static void Main(string[] args)
            {
                List<Employee> empList = new List<Employee>();
                empList.Add(new Employee(101, "Robert", 3000));
                empList.Add(new Employee(102, "John", 2000));
                EmployeeCamparer empComparer = new EmployeeCamparer();

                empList.Sort(empComparer);

                Console.WriteLine("------------------Employee Details---------------------\n");
                empList.ForEach(e => Console.WriteLine("Employee ID:" + e.EmpID + "\t" + "Employee Name:" + e.EmpName + "\t" + "Employee Salary:" + e.Salary + "\n"));


                List<Manager> mgrList = new List<Manager>();
                mgrList.Add(new Manager(101, "Robert", 3000, 1200));
                mgrList.Add(new Manager(102, "John", 2000, 1100));

                mgrList.Sort(empComparer);

                Console.WriteLine("------------------Manager Details---------------------\n");
                mgrList.ForEach(e => Console.WriteLine("Manager ID:" + e.EmpID + "\t" + "Manager Name:" + e.EmpName + "\t" + "Manager Salary:" + e.Salary + "\t"+"Manager Allowances:"+e.Allowance));





            }
        }
    }
}
