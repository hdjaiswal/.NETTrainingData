﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsymetricAccessDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assym emp = new Assym();
         //   emp.EmployeeID = 1;

            emp.EmployeeName = "John";
            emp.DOB = Convert.ToDateTime("20/02/2016");

            Console.ReadKey();


        }
    }
}
