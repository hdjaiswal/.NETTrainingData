﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsymetricAccessDemo
{
    class Assym
    {
        int empID;

        public int EmployeeID
        {

            get { return empID; }
            private set { empID = value; }

        }

        string name;

        public string EmployeeName
        {
            get { return name; }
            set { name = value; }
        }

        DateTime dob;

        public DateTime DOB
        {

            private get { return dob; }
            set { dob = value; }
        }

    }
}
