﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo
{
  public  class Employee
    {
       Employee()
      {
          Console.WriteLine("Deafult Constructor Of the class\n");
      }

      public Employee(string name)
      {
          Console.WriteLine("Paramerized Constructor of the Class\n");
      }

      static Employee()
      {
          Console.WriteLine("Static Constructor Of the class\n");
      }

        static void Main(string[] args)
        {

            Employee obj1 = new Employee();
            Employee obj2 = new Employee("Hello");
            Employee obj3 = new Employee();
            Console.ReadKey();
        
        }
    }
}
