﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodWirhParameterDemo
{
    public delegate double MathDelegate(int num,int pow);


    class Program
    {
        static void Main(string[] args)
        {
            MathDelegate del = delegate(int num, int pow)
            {
               return Math.Pow(num, pow);
                
            };
            double x=del(2,3);
            Console.WriteLine(x);
           Console.ReadKey();
        }
    }
}
