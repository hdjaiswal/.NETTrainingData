﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace MethodTypeInfo
{
    class Program
    {
        static void Main(string[] args)
        {
            Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type calc = refAssembly.GetType("ReflectionLibrary.Calculate");
            MethodInfo[] calcMethod = calc.GetMethods();

            for (int i = 0; i < calcMethod.Length; i++)
            {
                Console.WriteLine("*****************************Name : "+calcMethod[i].Name);
                Console.WriteLine("Is Private : " + calcMethod[i].IsPrivate);
                Console.WriteLine("Is Public : " + calcMethod[i].IsPublic);
                Console.WriteLine("Is Static : " + calcMethod[i].IsStatic);
                Console.WriteLine("Is Constructor : " + calcMethod[i].IsConstructor);
                Console.WriteLine("Return Type : " + calcMethod[i].ReturnType);
                ParameterInfo[] param = calcMethod[i].GetParameters();
                Console.WriteLine("No of PArameters : "+param.Length);
                foreach (ParameterInfo p in param)
                {
                    Console.WriteLine("Parameters  : " + p.Name);
                    Console.WriteLine("Parameters type : " + p.ParameterType);
                    Console.WriteLine("Parameters position : " + p.Position);
                }
                MethodInfo add = calc.GetMethod("add");
                if (add != null)
                {
                    object obj=refAssembly.CreateInstance("ReflectionLibrary.Calculate");
                    int result =(int) add.Invoke(obj,new object[] {20,30});
                    Console.WriteLine("Addition is : "+result);
                }
                

                MethodInfo subtract = calc.GetMethod("subtract");
                if (subtract != null)
                {
                    object obj = refAssembly.CreateInstance("ReflectionLibrary.dll");
                    int result = (int)subtract.Invoke(null, new object[] { 20, 30 });
                    Console.WriteLine("Subtraction is : "+result);
                }
            }



        }
    }
}
