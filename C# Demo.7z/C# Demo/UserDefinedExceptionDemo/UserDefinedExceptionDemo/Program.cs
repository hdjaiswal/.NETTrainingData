﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedExceptionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();

            try 
            {
                Console.Write("Enter Employee ID : ");
                emp.EmployeeID = Convert.ToInt32(Console.ReadLine());
                if (emp.EmployeeID < 100000 || emp.EmployeeID > 999999)
                {
                    throw new EmployeeException("Employee ID should be 6 digits only");
                    //throw new EmployeeException();
                }
            }
            catch (EmployeeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
