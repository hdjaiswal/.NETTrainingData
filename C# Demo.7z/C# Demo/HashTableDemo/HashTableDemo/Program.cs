﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace HashTableDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Hashtable hashObject = new Hashtable();
            hashObject.Add(1,".net");
            hashObject.Add(2,"java");
            hashObject.Add(3,"testing");
           
            foreach (int k in hashObject.Keys)
            {
            
                Console.WriteLine(k+"\t"+hashObject[k]);
              

                
            }
            if (hashObject.Contains(hashObject.Keys))
            {
                Console.WriteLine("Key is Present");
            }
        }
    }
}
