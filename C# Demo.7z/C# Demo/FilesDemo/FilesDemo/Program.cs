﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FilesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileInfo file = new FileInfo(@"D:\Module2 Data\Demo\getset.txt");
            if (file.Exists)
            {
                Console.WriteLine(file.FullName+"\n"+file.Extension+"\n"+file.DirectoryName+"\n"+file.LastAccessTime+"\n"+file.Length);
            }
            else
            {
                Console.WriteLine("File does not exist");
            }
            Console.ReadKey();
        }
    }
}
