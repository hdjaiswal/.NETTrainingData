﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringDemo
{
    class Program
    {
        public string StrConcat(params string[] str)
        {
            string result = "H";
            for (int i = 0; i < str.Length; i++)
            {
                result = result + str[i];
            }
            return result;
        }


        static void Main(string[] args)
        {
            Program obj = new Program();

            string j=obj.StrConcat(".Net","Batch");

            Console.WriteLine("Concatenated String is:" + j);

            Console.WriteLine("\n");




        }
    }
}
