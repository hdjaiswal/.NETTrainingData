﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoImplementedDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            AutoImple emp = new AutoImple();
            emp.EmployeeID = 1;

            emp.EmployeeName = "John";
            emp.DOB = Convert.ToDateTime("12/02/1996");
            emp.Salary = 23000;

            Console.WriteLine("Employee ID: " + emp.EmployeeID);

            Console.WriteLine("Salary: " + emp.Salary);

            Console.WriteLine("DOB: " + emp.DOB);
            Console.ReadKey();
        }
    }
}
