﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CovarianceDemo4._5
{
    public class Employee
    {

        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public double Salary { get; set; }
        public Employee(int empID, string name, double Sal)
        {
            EmpID = empID;
            EmpName = name;
            Salary = Sal;
            
        }

    }

    public class Manager : Employee
    {

        public Manager(int empID, string name, double Sal)
            : base(empID, name, Sal)
        {

        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            IList<Manager> mgr = new List<Manager>();
            mgr.Add(new Manager(101, "Robert", 2000));
            mgr.Add(new Manager(102, "John", 3000));

          
            IEnumerable<Employee> emp = mgr;
            foreach (Manager m in emp)
            {
                Console.WriteLine(m.EmpID+"\t"+m.EmpName+"\t"+m.Salary+"\n");
            }


        }
    }
}
