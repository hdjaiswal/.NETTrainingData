﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    public delegate void DelString();
    class Program
    {
        //public string Concat(string str1, string str2, string str3)
        //{
        //    return str1 + " " + str2 + " " + str3;
        //}

         
        
        static void Main(string[] args)
        {
            Program obj = new Program();
            DelString del = delegate { Console.WriteLine("XYZ"); };
            //string x=del("Hello","World","XYZ");
           // string x = del.Invoke("Hello", "World", "XYZ");
            del();

            //Console.WriteLine(x);

            

        }
    }
}
