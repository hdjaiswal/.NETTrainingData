﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualDemo
{
    public class Manager:Employee
    {
        public override void show()
        {
            Console.WriteLine("Inside Manager");
        }
    }
}
