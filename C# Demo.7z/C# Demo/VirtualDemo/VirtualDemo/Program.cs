﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VirtualDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Manager obj=new Manager();
            obj.show();
            Employee obj1 = new Manager();
            obj1.show();
           
        }
    }
}
