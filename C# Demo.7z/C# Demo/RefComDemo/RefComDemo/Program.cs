﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Word;

namespace RefComDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var application = new Microsoft.Office.Interop.Word.Application();

            string fileName = @"D:\Module2 Data\Demot.docx";
            application.Documents.Open(FileName: fileName);

        }
    }
}
