﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorDemo2
{
    class Program
    {
        static void Main(string[] args)
        {



            Employee emp2 = new Employee(23, "Hitesh", 23000);
            emp2.Print();

            //Employee emp = new Employee();
            Console.ReadKey();



        }
    }
}
