﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    public class Exception1
    {

        public Exception1()
    {
        int result=0;
    }
        public void Divide(int num1, int num2)
        {
            try
            {
                int Result = num1 / num2;

            }
            catch (DivideByZeroException e)
            {
                Console.WriteLine(e.Message);
            }

            finally
            {
                int result = 0;
                Console.WriteLine("result:" + result);
            }
        }

    }
}
