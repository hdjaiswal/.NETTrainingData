﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IEnumerableDemo
{
    public class daysoftheWeek
    {
        string[] days={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
        public IEnumerable DisplayDays()
        {
            for(int i=0;i<days.Length;i++)
            {
                yield return days[i];
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            daysoftheWeek week=new daysoftheWeek();


            foreach(string day in week.DisplayDays())
            {
                Console.WriteLine(day);
            }
            Console.ReadKey();

        }
    }
}
