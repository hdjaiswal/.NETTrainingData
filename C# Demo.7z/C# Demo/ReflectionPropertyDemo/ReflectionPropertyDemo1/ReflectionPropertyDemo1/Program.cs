﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace ReflectionPropertyDemo1
{
    class Program
    {
        static void Main(string[] args)
        {
              Assembly refAssembly = Assembly.LoadFrom("ReflectionLibrary.dll");
            Type calc = refAssembly.GetType("ReflectionLibrary.Calculate");
            PropertyInfo[] pinfo = calc.GetProperties();

            foreach(PropertyInfo m in pinfo)
            {
                Console.WriteLine("*****************************Name : "+m.Name);
                Console.WriteLine("Proeprty Type: " + m.PropertyType);
                Console.WriteLine("Member Type : " + m.MemberType);
            }
                 PropertyInfo p = calc.GetProperty("EmpID");
                if(p!=null)
                {
                Object obj=refAssembly.CreateInstance("ReflectionLibraryDemo.EmpID");
                    int ID = (int)p.Invoke(obj,new object  );
                    Console.WriteLine("Subtraction is : "+ID);
                }
            }
               
        }
    }
}
