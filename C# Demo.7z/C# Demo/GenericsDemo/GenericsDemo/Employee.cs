﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    public class Employee
    {
      public  int EmpID;
        public string EmpName;
       public double Salary;
    }
}
