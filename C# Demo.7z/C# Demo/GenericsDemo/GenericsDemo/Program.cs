﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> cityList = new List<string>();

            cityList.Add("Pune");
           // cityList.Add(123);  this could not be accepted because of integer type
           // cityList.Add(false);
            cityList.Add("Mumbai");

            cityList.Add("Banglore");
            cityList.Add("Chennai");
            cityList.Add("Hyderabad");

            Console.WriteLine("CityList:" );
            foreach (string item in cityList)
            {
                Console.WriteLine(item);
            }

            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() {EmpID=1, EmpName="Romesh", Salary=12000 });
            empList.Add(new Employee() { EmpID = 2, EmpName = "Raj", Salary = 52000 });
            empList.Add(new Employee() { EmpID = 3, EmpName = "Rohit", Salary = 42000 });
            empList.Add(new Employee() { EmpID = 4, EmpName = "Rohan", Salary = 22000 });

            Console.WriteLine("Employee List is:");
            foreach (Employee info in empList)
            {
                Console.WriteLine(info.EmpID+"\n"+info.EmpName+"\n"+info.Salary);
            }




        }
    }
}
