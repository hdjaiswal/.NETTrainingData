﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Abstract obj1 = new Derived();
            Abstract obj2 = new Derived();
      
        obj1.ShowMethod();
        obj2.VirtualMethod();
        }
    }
}
