﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    public class Derived:Abstract
    {


        public override void ShowMethod()
        {
            Console.WriteLine("Inside Derived Class");

        }
    }
}
