﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ArraysListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrlist = new ArrayList();
            arrlist.Add(10);
            arrlist.Add(".Net");
            arrlist.Add("java");
            arrlist.Add(1233.2111);
            arrlist.Add("Learning");
            arrlist.Add(false);
            Console.WriteLine("Number of Elements:"+arrlist.Count);
               Console.WriteLine("Arraylist capacity:"+arrlist.Capacity);

              
               object[] arr = new object[20];

               foreach (var val in arrlist)
               {

                   Console.WriteLine(val + " ");
               }
           //    arrlist.CopyTo(arr);
              
               arrlist.CopyTo(arr, 5);
               foreach (var val in arr)
               {

                   Console.WriteLine(val + "\t");
               }


        }
    }
}
