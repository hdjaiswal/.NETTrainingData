﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovarianceDemo
{
    public class Employee
    {

        public int EmpID { get; set; }
        public string EmpName { get; set; }
                public double Salary { get; set; }
        public Employee(int empID, string name,double Sal)
        {
            EmpID = empID;
            EmpName = name;
            Salary = Sal;
        }

    }

    public class Manager : Employee
    {

        public Manager(int empID, string name, double Sal)
            : base(empID, name, Sal)
        {
            
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            IList<Manager> mgr = new List<Manager>();
            mgr.Add(new Manager(101, "Robert", 2000));
            mgr.Add(new Manager(102, "John", 3000));

            Employee e = new Manager(1,"abc",786);
            IEnumerable<Employee> emp = mgr;
            foreach (Manager e in mgr)
            {
                Console.WriteLine(e);
            }
           

        }
    }
}
