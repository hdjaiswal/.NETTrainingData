﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyDemo
{
    class Property
    {
        int empID;
        public int EmployeeID
        {
            get { return empID; }
        }

        string name;

        public string EmployeeName
        {
            get { return name; }
            set { name = value; }
        }

        DateTime dob;
        public DateTime DOB
        {
            set { dob = value; }
        }

        public Property(int id)
        {
            this.empID=id;
        }

    }
}
