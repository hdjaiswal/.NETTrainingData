﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            Property emp = new Property(101);
         //   emp.EmployeeID = 102;
            emp.EmployeeName = "John";
            emp.DOB = Convert.ToDateTime("02/02/2017");

            Console.WriteLine("Employee ID: " + emp.EmployeeID);
            Console.WriteLine("Emplyee Name: " + emp.EmployeeName);

         //   Console.WriteLine("Employee ID: " + emp.DOB);

            Console.ReadKey();



        }
    }
}
