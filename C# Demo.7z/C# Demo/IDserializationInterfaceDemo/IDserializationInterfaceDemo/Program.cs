﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Soap;
using System.IO;

namespace IDserializationInterfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Student st=new Student(1,"Raj",30,20,25);

            FileStream fs = new FileStream("student.txt", FileMode.Create, FileAccess.Write);
            SoapFormatter bin = new SoapFormatter();
            bin.Serialize(fs, st);
            Console.WriteLine("Serialization Completed");
            fs.Close();
            fs = new FileStream("student.txt", FileMode.Open, FileAccess.Read);
            Student st1 = (Student)bin.Deserialize(fs);
            Console.WriteLine("Deserialization Completed");
            fs.Close();

            Console.WriteLine("Student Roll NO:" + st1.RollNo);
            Console.WriteLine("Student NAME:" + st1.SName);
            Console.WriteLine("Student Mark1:" + st1.Mark1);
            Console.WriteLine("Student Mark2:" + st1.Mark2);
            Console.WriteLine("Student Mark3:" + st1.Mark3);
          
        }
    }
}
