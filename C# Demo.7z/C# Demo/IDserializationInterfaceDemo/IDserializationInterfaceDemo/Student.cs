﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;


namespace IDserializationInterfaceDemo
{
    [Serializable]
    public class Student:IDeserializationCallback
    {
        int rollNo;
        string Name;
        double mark1;
        double mark2;
        double mark3;
        [NonSerialized]
        double totalMarks;
        double percentage;

        public int RollNo
        {
            get { return rollNo; }
            set { rollNo = value; }

        }
        public double Mark1
        {
            get { return mark1; }
            set { mark1 = value; }

        }
        public double Mark2
        {
            get { return mark2; }
            set { mark2 = value; }

        }

        public double Mark3
        {
            get { return mark3; }
            set { mark3 = value; }

        }

        public string SName
        {
            get { return Name; }
            set { Name = value; }

        }

        public Student(int _rollNo, string _Name, double _mark1, double _mark2, double _mark3)
        {
            rollNo = _rollNo;
            Name = _Name;
            mark1 = _mark1;
            mark2 = _mark2;
            mark3 = _mark3;
          

        }
        public void Calculatemarks()
        {
            totalMarks = mark1 + mark2 + mark3;
            Console.WriteLine("Total Marks of the student:" + totalMarks);
        }



        void IDeserializationCallback.OnDeserialization(object sender)
        {
            Calculatemarks();
        }
    }
}
