﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericMethodsDemo
{
  
    }
    public class Program
    {
          public void Swap<T>(ref T num1, ref T num2)
            {
                T temp;
                temp = num1;
                num1 = num2;
                num2 = temp;
            }
        static void Main(string[] args)
        {
              int a = 4;
                int b = 5;
                Console.WriteLine("--------------------------Before Swapping-------------------------------------");
                System.Console.WriteLine(a + " " + b);
            
            Program obj=new Program();

            Console.WriteLine("--------------------------After Swapping-------------------------------------");
                obj.Swap<int>(ref a, ref b);
                System.Console.WriteLine(a + " " + b);
        }
    }
