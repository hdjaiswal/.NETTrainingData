﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpression
{
    public delegate void LambdaDelegate();

    class Program
    {
        static void Main(string[] args)
        {
            LambdaDelegate anonymous = delegate 
            {
                Console.WriteLine("Anonymous Method called");
            };
            anonymous();

            LambdaDelegate lambda = () => Console.WriteLine("Lambda Expression called");
            lambda();

            Console.ReadKey();
        }
    }
}
