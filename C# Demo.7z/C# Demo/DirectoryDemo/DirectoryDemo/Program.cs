﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DirectoryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo dir = new DirectoryInfo(@"D:\Module2 Data\Demo");
            if (dir.Exists)
            {
                Console.WriteLine(dir.CreationTime + "\n" + dir.FullName + "\n" +dir.Parent );
            }
            else
            {
                Console.WriteLine("File does not exist");
            }
            Console.ReadKey();
        }
    }
}
