﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DirectoryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;

            Console.Write("Enter the path of directory about which you want information : ");
            path = Console.ReadLine();

            DirectoryInfo dir = new DirectoryInfo(path);

            if (dir.Exists)
            {
                Console.WriteLine("Directory Name is : " + dir.Name);
                Console.WriteLine("Directory Creation Time is : " + dir.CreationTime);
                Console.WriteLine("Directory Full Name is : " + dir.FullName);
                Console.WriteLine("Directory Last Access Time is : " + dir.LastAccessTime);
                Console.WriteLine("Directory Last Write Time is : " + dir.LastWriteTime);
                Console.WriteLine("Directory Parent is : " + dir.Parent);
                Console.WriteLine("Directory Root is : " + dir.Root);

                Console.WriteLine("Files from the Directories are : ");
                FileInfo[] files = dir.GetFiles();
                foreach (FileInfo f in files)
                {
                    Console.WriteLine("\t" + f.Name);
                }
            }
            else
            {
                Console.WriteLine("Directory does not exists");
            }
        }
    }
}
