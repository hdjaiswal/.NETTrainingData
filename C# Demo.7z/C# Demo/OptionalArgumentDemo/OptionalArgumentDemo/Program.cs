﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptionalArgumentDemo
{
    class Program
    {

        public void Addition(int num1, int num2=3, int num3=4)
        {
            Console.WriteLine("Addition {0},{1},{2}=>{3}" ,num1,num2,num3,(num1 + num2 + num3));
        }

        

     
        static void Main(string[] args)
        {
            Program add = new Program();
            Console.WriteLine("Optional Parameter Demo");
            add.Addition(2,3,5);

            Console.WriteLine("Named Argument Demo"); //Named Argument

            add.Addition(2, num2:6,num3:7);
           
        }
    }
}
