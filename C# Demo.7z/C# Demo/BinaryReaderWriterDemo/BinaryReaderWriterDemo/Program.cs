﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace BinaryReaderWriterDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream("binary.txt", FileMode.Create, FileAccess.Write);
            StreamWriter bw = new StreamWriter(fs);
            bw.WriteLine("Hello World");
            bw.WriteLine(".net");
            bw.WriteLine("java");
            bw.Flush();
            fs.Close();

            FileStream fs1 = new FileStream("binary.txt", FileMode.Open,FileAccess.Read);
            StreamReader br = new StreamReader(fs1);
       
            Console.WriteLine(br.ReadToEnd());
            fs1.Close();
        }
    }
}
