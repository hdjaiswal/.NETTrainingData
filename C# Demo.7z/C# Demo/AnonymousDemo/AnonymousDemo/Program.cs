﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            var emp1=new {EmployeeName="Robert",EmployeeSalary=12000};
            Console.WriteLine(emp1.EmployeeName + "\n" + emp1.EmployeeSalary);

        }
    }
}
