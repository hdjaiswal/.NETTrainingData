﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UserDefinedException
{
    class UserException
    {

        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public double Salary { get; set; }

       
    }
}
