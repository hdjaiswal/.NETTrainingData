﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUNIT.Framework;
using MathLibrary1;

namespace ClassLibraryTest
{
    public class MathTestClass
    {
    }
}
