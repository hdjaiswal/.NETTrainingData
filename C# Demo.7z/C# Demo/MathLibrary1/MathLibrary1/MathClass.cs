﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLibrary1
{
    public class MathClass
    {

        public int AddNumber(int num1, int num2)
        {
            return num1 + num2;
        }

        public int SubtractNumber(int num1, int num2)
        {
            return num1 - num2;
        }

        public int MultiplicationNumber(int num1, int num2)
        {
            return num1 * num2;
        }

        public int DivideNumber(int num1, int num2)
        {
            try
            {
                return num1 / num2;
            }
            catch(DivideByZeroException)
            {
                Console.WriteLine("Divide by Zero Error");
            }
        }
    }
}
