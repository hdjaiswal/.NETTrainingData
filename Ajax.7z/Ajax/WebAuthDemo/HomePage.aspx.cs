﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class HomePage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        GridView1.DataSource = Membership.GetAllUsers();
        Page.DataBind();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.City = "Mumbai";
        Profile.Name.FName = "Vinay";
        Profile.Name.LName = "Gupta";
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write(Profile.Name.FName + "  " + Profile.Name.LName);
        Response.Write("</br> Lives in : " + Profile.City);
    }
}