﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Clerk_Clerkdetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write(Profile.Name.FName + "  " + Profile.Name.LName);
        Response.Write("</br> Lives in : " + Profile.City);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Profile.City = "Mumbai";
        Profile.Name.FName = "Vinay";
        Profile.Name.LName = "Gupta";
    }
}