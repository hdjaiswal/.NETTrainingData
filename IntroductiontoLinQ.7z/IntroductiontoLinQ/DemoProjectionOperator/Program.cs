﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoProjectionOperator
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Bouquet> bouquets = new List<Bouquet>() {  
        new Bouquet { Flowers = new List<string> { "sunflower",
            "daisy", "daffodil", "larkspur" }},  
        new Bouquet{ Flowers = new List<string> { "tulip",
            "rose", "orchid" }},  
        new Bouquet{ Flowers = new List<string> { "gladiolis", 
            "lily", "snapdragon", "aster", "protea" }},  
        new Bouquet{ Flowers = new List<string> { "larkspur", 
            "lilac", "iris", "dahlia" }}  
    };

            // *********** Select ***********              
            IEnumerable<List<string>> query1 =
                bouquets.Select(bq => bq.Flowers);
             // ********* SelectMany *********  
            IEnumerable<string> query2 = 
                bouquets.SelectMany(bq => bq.Flowers);
             Console.WriteLine("Results by using Select():");
            // Note the extra foreach loop here.  
            foreach (IEnumerable<String> collection in query1)
                foreach (string item in collection)
                    Console.WriteLine(item);
            Console.ReadLine();
            Console.WriteLine("\nResults by using SelectMany():");
            foreach (string item in query2)
                Console.WriteLine(item);
            Console.ReadLine();

        }
        }
    }

    class Bouquet
    {
        public List<string> Flowers { get; set; }


    
    }
