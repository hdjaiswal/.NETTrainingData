﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoConversionOperators
{
    class Program
    {
        static void Main(string[] args)
        {

            object[] sequence = { 1, "Hello", 2.0 };
            var query = sequence.OfType<string>();
            foreach (var item in query)
                Console.WriteLine(item);
            Console.ReadLine();




        }
    }
}
