﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDistinctOperators
{   class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4 };
            int[] numbers2 = { 1, 1, 3, 3 };
            var numbers3 = numbers.Except(numbers2);
          
            //var numbers3 = numbers.Intersect(numbers2);
           // var numbers3 = numbers.Union(numbers2);

              foreach (var item in numbers3)
                Console.WriteLine(item);

            Console.ReadLine();


           


        }
    }
}
