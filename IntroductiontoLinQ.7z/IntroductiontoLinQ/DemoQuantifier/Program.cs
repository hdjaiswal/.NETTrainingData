﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoQuantifier
{
    class Program
    {
        static void Main(string[] args)
        {
            //Use the Any method to search for an odd numeric value as shown below:


            int[] numbers = { 2, 6, 24, 56, 102 };
            Console.WriteLine("Is there at least one odd number?");
            var flag = numbers.Any(e => e % 2 == 1);
            Console.WriteLine(flag);
            Console.ReadLine();

            Console.WriteLine("Are those all even numbers?");
            var flag1 = numbers.All(e => e % 2 == 0);

            int[] numbers2 = { 2, 6, 24, 56, 102 };
            Console.WriteLine("Is there the number 102?");
            var flag2 = numbers.Contains(102);
            Console.WriteLine(flag2);


        }
    }
}
