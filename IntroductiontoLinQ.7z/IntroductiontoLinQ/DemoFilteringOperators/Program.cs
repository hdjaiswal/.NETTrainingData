﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoFilteringOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            Developer[] developers = new Developer[] {
new Developer {Name = "Paolo", Language = "C#"},
new Developer {Name = "Marco", Language = "F#"},
new Developer {Name = "Frank", Language = "VB.NET"}};
            var developersUsingCSharp = 
                from d in developers
               //where d.Language == "C#"
                where d.Language == "C#" ||
                d.Language == "VB.NET"
           // where d.Language == "C#" && 
                //d.Language == "VB.NET"
           //order by
            orderby d.Name 
             // descending
                  select d;
                foreach (var item in developersUsingCSharp)
                { Console.WriteLine(item);
                 Console.ReadLine();
                }      }    }

    public class Developer
    {
        public string Name;
        public string Language;
        public int Age;
    }
}
