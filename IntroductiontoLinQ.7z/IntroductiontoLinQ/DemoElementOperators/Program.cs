﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoElementOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var query = numbers.First();
            Console.WriteLine("The first element in the sequence");
            Console.WriteLine(query);
            query = numbers.Last();
            Console.WriteLine("The last element in the sequence");
            Console.WriteLine(query);
            Console.WriteLine("The first even element in the sequence");
            query = numbers.First(n => n % 2 == 0);
            Console.WriteLine(query);
            Console.WriteLine("The last even element in the sequence");
            query = numbers.Last(n => n % 2 == 0);
            Console.WriteLine(query);

            Console.ReadLine();



            int[] numbers2 = { 1, 3, 5, 7, 9 };
            var query2 = numbers2.FirstOrDefault(n => n % 2 == 0);
            Console.WriteLine("The first even element in the sequence");
            Console.WriteLine(query2);
            Console.WriteLine("The last odd element in the sequence");
            query = numbers.LastOrDefault(n => n % 2 == 1);
            Console.WriteLine(query2);



            //int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //var query = numbers.Single(n => n > 8);
            //Console.WriteLine(query);

            //int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //var query = numbers.SingleOrDefault(n => n > 9);
            //Console.WriteLine(query);


            //int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //var query = numbers.ElementAt(4);
            //Console.WriteLine(query);

            //int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            //var query = numbers.ElementAtOrDefault(9);
            //Console.WriteLine(query);


        }
    }
}
