﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoConcatenationOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            int[] moreNumbers = { 10, 11, 12, 13 };
            var query = numbers.Concat(moreNumbers);
            foreach (var item in query)
                Console.WriteLine(item);
            Console.ReadLine();


        }
    }
}
