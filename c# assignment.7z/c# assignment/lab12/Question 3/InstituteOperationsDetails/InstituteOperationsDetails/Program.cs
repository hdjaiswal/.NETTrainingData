﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace InstituteOperationsDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            char ch;
            
            string[] sdir=new string[20];
            string[] file=new string[20];
                string[] path=new string[20];
                string[] path1 = new string[20];

                Console.WriteLine("\n------------------Institute Batch Details Operations----------------\n");

            Console.WriteLine("Enter Parent Directory Name:");
            string pdir = Console.ReadLine();
            string parentpath = Path.Combine(@"D:\", pdir);

            Console.WriteLine("\nEnter Subdirectory Name:");
            for (int i = 0; i < 4; i++)
            {
                sdir[i] = Console.ReadLine();
               
            }

            Console.WriteLine("\nEnter File Name in sub directories");
            for (int i = 0; i < 4; i++)
            {
                file[i] = Console.ReadLine();
                path1[i] = Path.Combine(parentpath, sdir[i]);
                path[i] = Path.Combine(path1[i], file[i]);
               
            }
            
            do
            {
                Console.WriteLine("\n-------------------Institute Batch Details Menu---------------------------\n");
                Console.WriteLine("\na:Create Directory Structure and Files\nb:Enter the batch Details\nc:Create backup copy of the academy\nd:View the details\n");
                Console.WriteLine("Enter Your Choice:");
                ch = Convert.ToChar(Console.ReadLine());
                switch (ch)
                {
                    case 'a':

                        DirectoryInfo pdr = new DirectoryInfo(parentpath);
                        pdr.Create();

                        for (int i = 0; i < 4; i++)
                        {
                            DirectoryInfo sdr = new DirectoryInfo(sdir[i]);
                            pdr.CreateSubdirectory(sdir[i]);

                            FileInfo fs = new FileInfo(path[i]);
                            fs.Create();
                            
                        }
                      

                        break;

                    case 'b':
                         Console.WriteLine("\nEnter the Path of the File to Write the details");
                        string writefile = Console.ReadLine();
                        //FileInfo fi=new FileInfo(disfile);
                        FileStream fw = new FileStream(writefile, FileMode.Open, FileAccess.Write);
                        StreamWriter bw = new StreamWriter(fw);
                        Console.WriteLine("\nEnter the details");
                        string details = Console.ReadLine();
                        bw.WriteLine(details);
                        bw.Flush();
                        fw.Close();

                        break;

                    case 'c':
            //            DirectoryInfo pdr1 = new DirectoryInfo(parentpath);
            //             DirectoryInfo[] directories = pdr1.GetDirectories();

            //foreach (DirectoryInfo directory in directories)
            //{
            //    // Get destination directory.
            //    string destinationDirectory = Path.Combine(targetDirectory.FullName, directory.Name);

            //    // Call CopyDirectoryTo() recursively.
            //    CopyDirectoryTo(directory, new DirectoryInfo(destinationDirectory));
                        
                        break;

                    case 'd':
                        Console.WriteLine("\nEnter the Path of the File to view the details");
                        string disfile = Console.ReadLine();
                        //FileInfo fi=new FileInfo(disfile);
                        FileStream fs1 = new FileStream(disfile, FileMode.Open, FileAccess.Read);
                        StreamReader br = new StreamReader(fs1);

                        Console.WriteLine(br.ReadToEnd());
                        fs1.Close();
                        break;
                }
                   Console.WriteLine("\nDo You want to continue (y/Y)");
                   ch = Convert.ToChar(Console.ReadLine());
                
               
            } while (ch == 'y'||ch=='Y');
            Console.ReadKey();

        }
    }
    }
