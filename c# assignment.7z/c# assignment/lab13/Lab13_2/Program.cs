﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Lab13_2
{
    [Serializable]
    public class Contact
    {
        public long ContactNo { get; set; }
        public String ContactName { get; set; }
        public string cellNo { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            //Lab 13.1
            Console.WriteLine("Enter ContactNo ");
            long Contact = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter Name ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter cell no ");
            string cellno =Console.ReadLine();

            Contact con = new Contact() { ContactNo = Contact, ContactName = name, cellNo = cellno };
            FileStream fs = new FileStream("contactSerialize.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, con);
            fs.Close();


            //Lab 13.2
            FileStream fs1 = new FileStream("contactSerialize.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter bf1 = new BinaryFormatter();
            Contact anotherEmp = (Contact)bf1.Deserialize(fs1);
            fs1.Close();

            Console.WriteLine("Contact no :" + anotherEmp.ContactNo);
            Console.WriteLine("Contact Name :" + anotherEmp.ContactName);
            Console.WriteLine("Cell No :" + anotherEmp.cellNo);
            Console.ReadKey();
        }
    }
}
