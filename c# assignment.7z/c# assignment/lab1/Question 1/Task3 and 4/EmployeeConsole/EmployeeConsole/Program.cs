﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails2;


namespace EmployeeConsole
{
    public class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[10];

            Console.WriteLine("--------------------------------Employee Details-------------------------------\n");



            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();

                Console.Write("Enter Employee ID : ");
                emp[i].EmployeeID = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Employee Name : ");
                emp[i].EmployeeName = Console.ReadLine();


                Console.Write("Enter Employee Address : ");
                emp[i].EmpAddress = Console.ReadLine();


                Console.Write("Enter Employee City : ");
                emp[i].Empcity = Console.ReadLine();

                Console.Write("Enter Employee Department : ");
                emp[i].Department = Console.ReadLine();

                Console.Write("Enter Employee Salary : ");
                emp[i].Salary = Convert.ToDouble(Console.ReadLine());
            }

            Console.Write("\n");

            for (int i = 0; i < emp.Length; i++)
            {
            
                Console.WriteLine("Employee Name is : " + emp[i].EmployeeName);
              
                Console.WriteLine("Employee Salary is : " + emp[i].Salary);
            }



            Console.WriteLine("\n");
            Console.ReadKey();
        
        }
    }
}
