﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails;

namespace EmployeeConsole
{
    class Program
    {
        static void Main(string[] args)
        {
             Employee emp = new Employee();

            Console.WriteLine("--------------------------------Employee Details-------------------------------\n");

                emp = new Employee();

                Console.Write("Enter Employee ID : ");
                int a = Convert.ToInt32(Console.ReadLine());
                emp.EmployeeID(a);

                Console.Write("Enter Employee Name : ");
                string b = Console.ReadLine();
                emp.EmployeeName(b);

                Console.Write("Enter Employee Address : ");
                string c = Console.ReadLine();
                emp.EmpAddress(c);

                Console.Write("Enter Employee City : ");
                string d = Console.ReadLine();
                emp.EmpCity(d);

                Console.Write("Enter Employee Department : ");
                string e = Console.ReadLine();
                emp.EmpDept(e);

                Console.Write("Enter Employee Salary : ");
                double f = Convert.ToDouble(Console.ReadLine());
                emp.EmpSalary(f);

                Console.WriteLine("\n");
                Console.ReadKey();
   
        
        }
    }
}
