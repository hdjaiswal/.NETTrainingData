﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    public class Employee
       {
       int EmpID;
       string EmpName;
       string Address;
       string City;
       string Dept;
       double Salary;

       public void EmployeeID(int ID)
       {
           EmpID = ID;
       }

       public void EmployeeName(string Name)
       {
           EmpName = Name;
       }

       public void EmpAddress(string Addr)
       {
           Address = Addr;
       }

       public void EmpCity(string Ct)
       {
           City = Ct;
       }

       public void EmpDept(string Empdpt)
       {
           Dept = Empdpt;
       }

       public double EmpSalary(double Sal)
       {
           Salary = Sal;
           return Salary;
       }
        
    }
}

