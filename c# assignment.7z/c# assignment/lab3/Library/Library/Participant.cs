﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Participant
    {
        int empId;
        string empName;
        static string companyName;
        int foundationMarks, dotNetMarks, webBasicMarks, totalMarks = 300, obtainedMarks;
        double percentage;

        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public int FoundationMarks { get; set; }
        public int WebBasicMarks { get; set; }
        public int DotNetMarks { get; set; }
        public int TotalMarks { get; set; }

        public Participant()
        {
            Console.WriteLine("Default Constructor");
        }
        public Participant(int Id, string name, int FMarks, int DMarks, int WMarks)
        {
            empId = Id;
            empName = name;
            foundationMarks = FMarks;
            dotNetMarks = DMarks;
            webBasicMarks = WMarks;

        }
        static Participant()
        {
            companyName = "Corporate Unniversity";
        }

        public int ObtainedMarks()
        {
            return foundationMarks + dotNetMarks + webBasicMarks;
        }
        public double Percentage()
        {
            return ((ObtainedMarks()/totalMarks) * 100);
        }
        static void Main(string[] args)
        {
            Participant p = new Participant();

            Console.Write("Enter Employee ID : ");
            p.empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Name : ");
            p.empName = Console.ReadLine();
            Console.Write("\nEnter FoundationMarks : ");
            p.foundationMarks = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter WebBasicMarks : ");
            p.webBasicMarks = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nEnter DotNetMarks : ");
            p.dotNetMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("EmpID            :" + p.empId);
            Console.WriteLine("Employee Name    :" + p.empName);
            Console.WriteLine("Company name     :" + Participant.companyName);
            Console.WriteLine("Marks Obtained   :" + p.ObtainedMarks());
            Console.WriteLine("Percentage       :" + p.Percentage());

            

        }
    }
}

