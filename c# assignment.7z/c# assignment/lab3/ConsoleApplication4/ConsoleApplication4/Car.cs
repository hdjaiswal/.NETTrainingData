﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Car
    {
        string car;
        string details;
        public string carName 
        {
            get { return car; }
            set { car = value; }
        }
        public string carDetails 
        {
            get{return details;}
            set { details = value; }
        }
    }
}
