﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice,i=0;
            Car[] c = new Car[10];
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("                 Car Showroom");
            Console.WriteLine("-------------------------------------------------");
            Console.WriteLine("Choices");
            Console.WriteLine("-------------------------------------------------");
            while (true)
            {
                string name; ;
                Console.WriteLine("1)Add Car");
                Console.WriteLine("2)List all cars in catalog");
                Console.WriteLine("3)Quit");
                Console.WriteLine("4)Search");
                choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    c[i] = new Car();
                    Console.Write("Enter name of the Car :");
                    c[i].carName = Console.ReadLine();
                    Console.WriteLine("Car added success fully");
                    i++;
                }
                else if (choice == 2)
                {
                    for (int j = 0; j < i; j++)
                    {
                        Console.WriteLine("{0}){1}",j, c[j].carName);
                    }
                }
                else if (choice == 3)
                {
                    Environment.Exit(0);
                }
                else if (choice == 4)
                {
                    bool a = false;
                    int b=0;
                    Console.WriteLine("Enter the name you want search");
                    string namec = Console.ReadLine();
                    Predicate<string> pra=delegate(string c){return namec};
                    for (int k = 0; k <i; k++)
                    {
                        if (Array.Exists(c[i].carName,))
                        {
                            a = true;
                            b=i;
                        }
                    }
                    if (a == true)
                    {
                        Console.WriteLine("Car found at position {0}", i);
                        Console.WriteLine("Car Description: {0}", c[i].carDetails);
                    }
                }
                else
                {
                    Console.WriteLine("Wrong Option Selected");
                }
                Console.WriteLine("-----------------------------------------------------");
            }
        }
    }
}
