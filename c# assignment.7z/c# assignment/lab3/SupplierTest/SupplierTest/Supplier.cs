﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierTest
{
    public class Supplier
    {
        int supplierID;
        string supplierName;
        string city;
        string phoneNo;
        string email;

        public void AcceptDetails()
        {
            Console.Write("Enter Supplier ID : ");
            supplierID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Supplier Name : ");
            supplierName = Console.ReadLine();
            Console.Write("Enter City : ");
            city = Console.ReadLine();
            Console.Write("Enter Phone No. : ");
            phoneNo = Console.ReadLine();
            Console.Write("Enter Email ID : ");
            email = Console.ReadLine();
        }
        public void DisplayDetails()
        {
            Console.WriteLine("\nSuppliers Details are : ");
            Console.WriteLine("Supplier ID is : " +supplierID+ "\nSupplier Name is : "+ supplierName+ "\nCity is : " +city+ "\nPhone No. is : " +phoneNo+ "\nEmail ID is : "+ email);
 
        }
    }
}
