﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10_1
{
    delegate void ArithmeticDelegate (int num1, int num2);
    public class ArithmeticOperation
    {
        public void Add(int num1, int num2)
        {
            
            Console.WriteLine("Sum of {0} & {1} is {2}", num1, num2, num1 + num2);
        }
        public void Subtract(int num1, int num2)
        {
            Console.WriteLine("Difference of {0} & {1} is {2}", num1, num2, (num1 - num2));
        }
        public void Multiply(int num1, int num2)
        {
            Console.WriteLine("Product of {0} & {1} is {2}", num1, num2, (num1 * num2));
        }
        public void Divide(int num1, int num2)
        {
            Console.WriteLine("Quotient of {0} & {1} is {2}", num1, num2, (num1 / num2));
        }
        public void Max(int num1, int num2)
        {
            if (num1 > num2)
                 Console.WriteLine("{0} is maximum",num1);
            else if (num1 < num2)
                 Console.WriteLine("{0} is maximum",num2);
            else  Console.WriteLine("{0} & {1} are equal ",num1,num2);

        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperation oper = new ArithmeticOperation();
            ArithmeticDelegate adel = new ArithmeticDelegate(oper.Multiply);

            Console.WriteLine("Enter num1 :");
            int n1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter num2 :");
            int n2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the operation u wish to perform");
           
            char ch='h';
            do{
                Console.WriteLine("+ to Add \t- to subtract \t* to Multiply \t/ to divide \tm to find max");
                char choice = Convert.ToChar(Console.ReadLine());
                switch (choice)
                {
                    case '+': adel = new ArithmeticDelegate(oper.Add);
                            adel(n1, n2);
                            break;
                    case '-': adel = new ArithmeticDelegate(oper.Subtract);
                            adel(n1, n2);
                            break;
                    case '*': adel = new ArithmeticDelegate(oper.Multiply);
                            adel(n1, n2);
                            break;
                    case '/': adel = new ArithmeticDelegate(oper.Divide);
                            adel(n1, n2);
                            break;
                    case 'm': adel = new ArithmeticDelegate(oper.Max);
                            adel(n1, n2);
                            break;
                    default: Console.WriteLine("Pls enter a valid operation");
                            break;
                }
                Console.WriteLine("Do u wanna continue");
                ch = Convert.ToChar(Console.ReadLine());
            }while(ch=='y' || ch=='Y');
            
        }
    }
}
