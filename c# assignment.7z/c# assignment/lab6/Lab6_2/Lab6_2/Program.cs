﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_2
{
   public class DataEntryException : ApplicationException
    {
        public DataEntryException()
            : base()
        { }
        public DataEntryException(string message)
            : base(message)
        { }
    }
    public class ProductMock
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public double Price { get; set; }

        public ProductMock()
        {
        }
        public ProductMock(int ProductId, string ProductName, double Price)
        {
            this.ProductId = ProductId;
            this.ProductName = ProductName;
            this.Price = Price;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Product ID :");
                int ProductId = Convert.ToInt32(Console.ReadLine());
                if (ProductId <= 0)
                    throw new DataEntryException("Enter valid product id");
                Console.WriteLine("Enter Product Name :");
                string name = Console.ReadLine();
                if (name == "")
                    throw new DataEntryException("Enter a valid name ");
                Console.WriteLine("Enter Product Price :");
                double price = Convert.ToDouble(Console.ReadLine());
                if (price <=0 )
                {
                    throw new DataEntryException("Price cannot be negative or 0 ");
                }
            }
            catch (DataEntryException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

