﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDetails
{
    public class Triangle:Shape
    {

        public override void WhoamI()
        {
            Console.WriteLine("I m Triangle");
        }

    }
}
