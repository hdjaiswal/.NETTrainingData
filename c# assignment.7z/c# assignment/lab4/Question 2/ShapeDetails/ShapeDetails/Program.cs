﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapeDetails
{
    public class Program
    {
        static void Main(string[] args)
        {
            Shape s = new Triangle();
            s.WhoamI();
           Shape s1 = new Circle();
            s1.WhoamI();
            Console.ReadKey();
        }
    }
}
