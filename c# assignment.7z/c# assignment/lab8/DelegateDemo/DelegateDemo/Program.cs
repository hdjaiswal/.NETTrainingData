﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    public delegate string DelString(String str1, string str2, string str3);

    class Program
    {
        public string concat(String str1, string str2, string str3)
        {
            return str1 + "" + str2 + "" + str3;
        }
     
        
        static void Main(string[] args)
        {
            Program p = new Program();
            DelString del = new DelString(p.concat);
            string result = del("Hello", ".Net", "Batch");
            Console.WriteLine(result);

            del = new DelString(string.Concat);

            Console.ReadKey();
        }
    }
}
