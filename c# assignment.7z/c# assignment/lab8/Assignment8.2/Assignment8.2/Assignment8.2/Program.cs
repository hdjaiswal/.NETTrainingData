﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Assignment8._2
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Hashtable hs = new Hashtable();
            hs.Add("Area", 1000);
            hs.Add("Perimeter", 55);
            hs.Add("Mortgage", 540);

            Console.WriteLine(hs.Contains("Perimeter"));
            Console.WriteLine(hs.ContainsKey("Perimeter"));

            Console.WriteLine(hs.ContainsValue(1000));

            hashtable.Remove("Mortgage");
            foreach (var ele in hs.Keys)
            {
                Console.WriteLine(" keys :"+ele +" values : "+hs[ele].ToString());
            }
            

        }
    }
}
