﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDetails
{
    class BookDemo
    {
        static void Main(string[] args)
        {
             string[,] bookDetails = new string[1, 2];
             string[] booktitle=new string[2];
            string[] bookauthor=new string[2];
            string[] bookpub=new string[2];
             double[] price=new double[2];

             Console.WriteLine("\n -------------------Book Details---------------------");

            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {

                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    Console.WriteLine("Enter the Book title :");
                    booktitle[j] =Console.ReadLine();
                    Console.WriteLine("Enter the Author of Book :");
                    bookauthor[j] = Console.ReadLine();
                    Console.WriteLine("Enter the publisher of Book :");
                    bookpub[j] = Console.ReadLine();
                    Console.WriteLine("Enter price of book :");
                    price[j] = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("\n");
                }
                
            }
       
            for (int i = 0; i < bookDetails.GetLength(0); i++)
            {
                for (int j = 0; j < bookDetails.GetLength(1); j++)
                {
                    Console.WriteLine("Book Title : " + booktitle[j]);
                    Console.WriteLine("Author of Book : " + bookauthor[j]);
                    Console.WriteLine("Publisher of Book  : " + bookpub[j]);
                    Console.WriteLine("Price of Book : " + price[j]);
                    Console.WriteLine("\n");
                }
              
            }
        }
    }
}
